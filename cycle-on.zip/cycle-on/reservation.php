<?php
$id = filter_input(INPUT_POST, 'id');
$bikeid = filter_input(INPUT_POST, 'bikeid');
$days= filter_input(INPUT_POST, 'days');
$from = filter_input(INPUT_POST, 'from');
$to= filter_input(INPUT_POST, 'to');
$cost=500;
$price= $days*$bikeid*$cost;

if (!empty($id)){
if (!empty($bikeid)){
$host = "127.0.0.1";
$dbusername = "root";
$dbpassword = "kolikoli";
$dbname = "DBMSproject";
// Create connection
$conn = new mysqli ($host, $dbusername, $dbpassword, $dbname);


if (mysqli_connect_error()){
die('Connect Error ('. mysqli_connect_errno() .') '
. mysqli_connect_error());
}
else{
$sql = "INSERT INTO `cyclebooking` (`id`, `VehicleId`, `FromDate`, `ToDate`, `Status`)
values ($id, $bikeid, $from,$to,1)";
if ($conn->query($sql)){
echo "Cycle booked sucessfully and you are billed for Rs ";
print($days*$bikeid*$cost);
}
else{
echo "Error: ". $sql ."
". $conn->error;
}
$conn->close();
}
}
else{
echo "bikeid should not be empty";
die();
}
}
else{
echo "id should not be empty";
die();
}

?>

<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<p><a href="price.html">Continue Renting</a></p>
</body>
</html>

