<?php
$FullName = filter_input(INPUT_POST, 'FullName');
$EmailId = filter_input(INPUT_POST, 'email');
$Password = filter_input(INPUT_POST, 'psw');
$ContactNo = filter_input(INPUT_POST, 'ContactNo');
$dob = filter_input(INPUT_POST, 'dob');
$Address = filter_input(INPUT_POST, 'Address');
$Semester = filter_input(INPUT_POST, 'Semester');
$BranchCode = filter_input(INPUT_POST, 'Branchcode');

if (!empty($FullName)){
if (!empty($EmailId)){
if (!empty($Password)){
if (!empty($ContactNo)){
if (!empty($dob)){
if (!empty($Address)){
if (!empty($Semester)){
if (!empty($BranchCode)){
$host = "127.0.0.1";
$dbusername = "root";
$dbpassword = "kolikoli";
$dbname = "DBMSproject";
// Create connection
$conn = new mysqli ($host, $dbusername, $dbpassword, $dbname);


if (mysqli_connect_error()){
die('Connect Error ('. mysqli_connect_errno() .') '
. mysqli_connect_error());
}
else{
$sql = "INSERT INTO users (FullName, EmailId,Password,ContactNo,dob,Address,Semester,BranchCode)
values ('$FullName','$EmailId','$Password','$ContactNo','$dob','$Address','$Semester','$BranchCode')";
if ($conn->query($sql)){
echo "New user is registered sucessfully";
}
else{
echo "Error: ". $sql ."
". $conn->error;
}
$conn->close();
}
}
    
else{
    echo "BranchCode should not be empty";
    die();
}
}
    else{
        echo "Semester should not be empty";
            die();
    }
}
    else{
        echo "Address should not be empty";
        die();
    }
}
     else{
        echo "dob should not be empty";
        die();
    }
}
     else{
        echo "ContactNo should not be empty";
        die();
    }
}
else{
echo "Password should not be empty";
die();
}
}
     else{
        echo "EmailId should not be empty";
        die();
    }
}
else{
echo "FullName should not be empty";
die();
}
    
?>
<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<p><a href="homepage.html">Go to home page</a></p>
</body>
</html>
