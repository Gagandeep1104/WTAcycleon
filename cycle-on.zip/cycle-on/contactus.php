<?php
$id = filter_input(INPUT_POST, 'id');
$email = filter_input(INPUT_POST, 'email');
$parking_no = filter_input(INPUT_POST, 'parking_no');
$subject = filter_input(INPUT_POST, 'subject');



if (!empty($id)){
if (!empty($email)){
if (!empty($parking_no)){
if (!empty($subject)){
$host = "127.0.0.1";
$dbusername = "root";
$dbpassword = "kolikoli";
$dbname = "DBMSproject";
// Create connection
$conn = new mysqli ($host, $dbusername, $dbpassword, $dbname);


if (mysqli_connect_error()){
die('Connect Error ('. mysqli_connect_errno() .') '
. mysqli_connect_error());
}
else{
$sql = "INSERT INTO `contactus` (`id`, `Alternate_contact_info`, `parking_no`, `Subject`)
values ('$id','$email','$parking_no','$subject')";
if ($conn->query($sql)){
echo "We will contact you as soon as possible, Thank you";
}
else{
echo "Error: ". $sql ."
". $conn->error;
}
$conn->close();
}
}
    
else{
    echo "Subject should not be empty";
    die();
}
}
    else{
        echo "ParkingNo should not be empty";
            die();
    }
}
    else{
        echo "email should not be empty";
        die();
    }
}
     else{
        echo "id should not be empty";
        die();
    }

    
?>
<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<p><a href="homepage.html">Go to home page</a></p>
</body>
</html>
