create database DBMSproject;
use DBMSproject;
show tables;
select * from admin;
select * from branch;
select * from brands;
select * from contactus;
select * from login;
select * from subscribersnew;
select * from users;
select * from vehicles;
select * from cyclebooking;
select * from bookedrides;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL primary key ,
  `name` varchar(100) NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL
);



ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;

CREATE TABLE IF NOT EXISTS `login` (
  `id` int(11) NOT NULL,
  `password` varchar(100) NOT NULL,
  foreign key(id) references users(id)
);


INSERT INTO `login` (`id`,  `Password`) VALUES
(31, 'NITK');

INSERT INTO `admin` (`id`, `name`,`UserName`, `Password`) VALUES
(11, 'Gagan','NITK', 'NITK');



CREATE TABLE IF NOT EXISTS `branch` (
  `branchcode` int(11) NOT NULL AUTO_INCREMENT,
  `Branchname` varchar(100),
  PRIMARY KEY (Branchcode));



INSERT INTO `branch`(`branchname`) VALUES
('CSE'),
('IT'),
('ECE'),
('EEE'),
('ME'),
('CE'),
('META'),
('MN'),
('CVE');


CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL primary key AUTO_INCREMENT,
  `FullName` varchar(120) DEFAULT NULL,
  `EmailId` varchar(100) DEFAULT NULL,
  `Password` varchar(100) DEFAULT NULL,
  `ContactNo` char(11) DEFAULT NULL,
  `dob` varchar(100) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `Semester` int(10) DEFAULT NULL,
  `Branchcode` int(10) DEFAULT NULL,
  `RegDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(Branchcode) REFERENCES branch(Branchcode)
);


  ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;





INSERT INTO `users` (`id`, `FullName`, `EmailId`, `Password`, `ContactNo`, `dob`, `Address`, `Semester`, `Branchcode`, `RegDate`) VALUES
(31, 'Gagan deep', 'gagan@gmail.com', 'abcd', '2147483647', NULL, NULL, NULL, NULL, '2017-06-17 19:59:27'),
(32, 'prithvi', 'prithvi@gmail.com', 'abcd', '8285703354', NULL, NULL, NULL, NULL, '2017-06-17 20:00:49'),
(33, 'atharv', 'atharv@gmail.com', 'abcd', '09999857868', '03/02/1990', 'PKL', 4, 41, '2017-06-17 20:01:43'),
(34, 'NITK', 'test@gmail.com', 'abcd', '9999857868', '', 'PKL', 3, 41, '2017-06-17 20:03:36');



CREATE TABLE IF NOT EXISTS `vehicles` (
  `id` int(11) NOT NULL primary key,
  `VehiclesTitle` varchar(150) DEFAULT NULL,
  `VehiclesBrand` int(11) DEFAULT NULL,
  `VehiclesOverview` longtext,
  `PricePerDay` int(20) DEFAULT NULL,
  `FuelType` varchar(100) DEFAULT NULL,
  `ModelYear` int(20) DEFAULT NULL,
  `SeatingCapacity` int(11) DEFAULT NULL,
  `Vimage1` varchar(120) DEFAULT NULL,
  `Vimage2` varchar(120) DEFAULT NULL,
  `Vimage3` varchar(120) DEFAULT NULL,
  `Vimage4` varchar(120) DEFAULT NULL,
  `Vimage5` varchar(120) DEFAULT NULL,
  `AntiLockBrakingSystem` int(11) DEFAULT NULL,
  `BrakeAssist` int(11) DEFAULT NULL,
  `CrashSensor` int(11) DEFAULT NULL,
  `LeatherSeats` int(11) DEFAULT NULL,
  `RegDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (VehiclesBrand) REFERENCES brands(id)
);



INSERT INTO `vehicles` (`id`) VALUES
(1);






CREATE TABLE IF NOT EXISTS `cyclebooking` (
  `id` int(11) NOT NULL ,
  `VehicleId` int(11) DEFAULT NULL,
  `FromDate` varchar(20) DEFAULT NULL,
  `ToDate` varchar(20) DEFAULT NULL,
  `Status` int(11) DEFAULT NULL,
  `PostingDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(id) REFERENCES users(id),
  FOREIGN KEY(VehicleId) REFERENCES vehicles(id)
);



INSERT INTO `cyclebooking` (`id`, `VehicleId`, `FromDate`, `ToDate`, `Status`, `PostingDate`) VALUES
(31, 1, '22/06/2017', '25/06/2017', 1, '2017-06-19 20:15:43'),
(32, 1, '30/06/2017', '02/07/2017', 2, '2017-06-26 20:15:43'),
(33, 1, '02/07/2017', '07/07/2017', 0, '2017-06-26 21:10:06');



CREATE TABLE IF NOT EXISTS `brands` (
  `id` int(11) NOT NULL PRIMARY KEY,
  `BrandName` varchar(120) NOT NULL
 
) ;



INSERT INTO `brands` (`id`, `BrandName`) VALUES
(1, 'Hero'),
(2, 'Atlas' ),
(3, 'BTwin' ),
(4, 'Suzuki'),
(5, 'Yamaha'),
(7, 'Ducati');



CREATE TABLE IF NOT EXISTS `contactus` (
  `caseid` int(11) NOT NULL PRIMARY KEY,
  `id` int(11) NOT NULL,
  `Alternate_contact_info` varchar(255) DEFAULT NULL,
  `parking_no` int(11) NOT NULL,
  `Subject` longtext,
  FOREIGN KEY (id) REFERENCES users(id)
);

ALTER TABLE `contactus`
  MODIFY `caseid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=100;

INSERT INTO `contactus` (`caseid`,`id`, `Alternate_contact_info`, `parking_no`, `Subject`) VALUES
(1,31, 'gagant@test.com/9986655357',2,'sometext or complain');





CREATE TABLE IF NOT EXISTS `subscribersnew` (
  `subid` int(11) NOT NULL PRIMARY KEY,
  `id` int(11) NOT NULL,
  `Version` varchar(120) DEFAULT NULL,
  `PostingDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (id) REFERENCES users(id)
);

ALTER TABLE `subscribersnew`
  MODIFY `subid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;


INSERT INTO `subscribersnew` (`subid`,`id`, `Version`, `PostingDate`) VALUES
(1,31, 'highend', '2017-06-22 16:35:32');


ALTER TABLE `brands`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;


ALTER TABLE `vehicles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;

DELIMITER 
create trigger safety0 AFTER DELETE ON user for each row
begin
print'deleted user details'
end; 
DELIMITER ;

CREATE TRIGGER safety1
ON DATABASE
FOR DROP_TABLE, ALTER_TABLE
AS 
begin
  PRINT 'you must disable trigger to drop or alter'
ROLLBACK
END;

CREATE VIEW bookedrides AS
SELECT id , VehicleId
FROM  cyclebooking
WHERE Status=1
WITH CHECK OPTION;

CREATE PROCEDURE bookedbikes(status
nvarchar(30))
select * from cyclebooking where status = status;


